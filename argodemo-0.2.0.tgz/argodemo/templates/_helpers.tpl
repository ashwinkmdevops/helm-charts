{{- define "argo-demo.fullName" -}}
{{- $fullName := printf "%s-%s" .Release.Name .Chart.Name  }}
{{- .Values.fullName | default $fullName | trunc 63 | trimSuffix "-" }}
{{- end -}}


{{- define "argo-demo.liveService" -}}
{{- $default := printf "%s-live" (include "argo-demo.fullName" .) | trunc 63 | trimSuffix "-" -}}
{{- .Values.controller.liveService | default $default | trunc 63 | trimSuffix "-" }}
{{- end -}}


{{- define "argo-demo.previewService" -}}
{{- $default := printf "%s-preview" (include "argo-demo.fullName" .) | trunc 63 | trimSuffix "-" -}}
{{- .Values.controller.previewService | default $default | trunc 63 | trimSuffix "-" }}
{{- end -}}


{{/*
  Selector labels — stable subset used in matchLabels and Service selectors.
  Must NOT change after initial deployment (selectors are immutable).
*/}}
{{- define "argo-demo.selectorLabels" -}}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}


{{/*
  Full labels — used in resource metadata.labels.
  Includes version and managed-by on top of selectorLabels.
*/}}
{{- define "argo-demo.labels" -}}
{{ include "argo-demo.selectorLabels" . }}
app.kubernetes.io/version: {{ .Values.image.tag | default .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}


{{- define "argo-demo.targetPort" -}}
{{- .Values.targetPort }}
{{- end -}}

{{- define "argo-demo.apiVersion" -}}
{{- if eq .Values.controller.type "Rollout" -}}
argoproj.io/v1alpha1
{{- else if eq .Values.controller.type "Deployment" -}}
apps/v1
{{- else -}}
apps/v1
{{- end -}}
{{- end -}}

{{- define "argo-demo.strategy" -}}
{{- $type := .Values.controller.strategy.type | lower }}

{{- if eq $type "bluegreen" -}}
blueGreen:
  activeService: {{ include "argo-demo.liveService" . }}
  previewService: {{ include "argo-demo.previewService" . }}
  autoPromotionEnabled: {{ .Values.controller.strategy.autoPromotionEnabled }}
  autoPromotionSeconds: {{ .Values.controller.strategy.autoPromotionSeconds }}

{{- else if eq $type "canary" -}}
canary:
  stableService: {{ include "argo-demo.liveService" . }}
  canaryService: {{ include "argo-demo.previewService" . }}
  trafficRouting:
    plugins:
      argoproj-labs/gatewayAPI:
        httpRoute: {{ include "argo-demo.liveService" . }}-https
        namespace: {{ .Release.Namespace }}
{{ toYaml .Values.controller.strategy.canarySpec | indent 2 }}

{{- else if eq $type "recreate" -}}
type: Recreate
{{- else if eq $type "rollingupdate" -}}
type: RollingUpdate
rollingUpdate:
  maxSurge: {{ .Values.controller.strategy.rollingUpdate.maxSurge }}
  maxUnavailable: {{ .Values.controller.strategy.rollingUpdate.maxUnavailable }}
{{- else }}
{{- fail (printf "Unsupported strategy type: %s" $type) }}
{{- end }}
{{- end }}


{{- define "argo-demo.previewServiceInLiveHTTPRoute" -}}
{{- if eq .Values.controller.strategy.type "canary" -}}
- name: {{ include "argo-demo.previewService" . }}
  port: 80
{{- end -}}
{{- end -}}
